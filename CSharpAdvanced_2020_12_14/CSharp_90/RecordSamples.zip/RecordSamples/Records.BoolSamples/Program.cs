﻿using System;

namespace Records.BoolSamples
{

    public record Person(string Vorname, string Nachname);
    public class PersonClassSample
    {
        public string Vorname { get; init; }
        public string Nachname { get; init; }

        public PersonClassSample()
        {
            Vorname = Nachname = string.Empty;
        }
        public PersonClassSample(string vorname, string nachname)
        {
            this.Vorname = vorname;
            this.Nachname = nachname;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            
            Person person = new("Kevin", "Winter");
            (string vorname, string nachname) = person;
            Console.WriteLine($"Ausgabe {vorname} {nachname}");
        

            Person person1 = new("Kevin", "Winter");

            PersonClassSample personClass1 = new("Max", "Mustermann");
            PersonClassSample personClass2 = new("Max", "Mustermann");
            PersonClassSample personClass = new();

            Console.WriteLine($"Compare Records with the == Operator : {person == person1}");
            Console.WriteLine($"Compare Classes with the == Operator : {personClass1 == personClass2}");

            Console.WriteLine($"Compare Records with the Equals Method : {person.Equals(person1)}");
            Console.WriteLine($"Compare Classes with the Equals Method : {personClass1.Equals(personClass2)}");
            Console.ReadLine();

            //Compare Records with the == Operator : True
            //Compare Classes with the == Operator : False
            //Compare Records with the Equals Method : True
            //Compare Classes with the Equals Method : False
        }
    }
}
