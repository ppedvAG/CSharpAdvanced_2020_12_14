﻿using System;

namespace RecordSample.Dekonstruktor
{
    public record Person(string Vorname, string Nachname);
    class Program
    {
        static void Main(string[] args)
        {
            Person p = new("Kevin", "Winter");
            (string Vorname, string Nachname) = p;
            Console.WriteLine($"{Vorname} {Nachname}");
            Console.ReadKey();
        }
    }
}
