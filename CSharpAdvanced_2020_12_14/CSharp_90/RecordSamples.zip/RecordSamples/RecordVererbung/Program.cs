﻿using System;

namespace RecordVererbung
{
    public record Person (string Vorname, string Nachname);

    public record Angestellter(string Vorname, string Nachname, string Arbeitgeber, DateTime AngestelltSeit) 
        : Person(Vorname, Nachname);

    class Program
    {
        static void Main(string[] args)
        {
            Angestellter arbeiter = new(
                "Kevin", 
                "Winter", 
                "PPEDV", 
                new DateTime(2019, 11, 1));
            Console.WriteLine($"{arbeiter.Vorname}{arbeiter.Nachname}");
            //Console.WriteLine($"arbeitet seit {arbeiter.AngestelltSeit} bei {arbeiter.Arbeitgeber}");
        }
    }
}
