﻿using System;

namespace Records.BoolSamples2
{
    public record Radio (string Brand, string Modell);
    public record Car (string Brand, string Modell, Radio radio);
    class Program
    {
        static void Main(string[] args)
        {
            Car car1 = new("BMW", "Z8", new Radio("Telefunk", "Model1"));
            Car car2 = new("BMW", "Z8", new Radio("Telefunk", "Model1"));
            Console.WriteLine($"Compare Records with the == Operator : {car1 == car2}");
            Console.WriteLine($"Compare Records with the Equals Methode : {car1.Equals(car2)}");
            Console.WriteLine($"Ausgabe mit ToString() : {car1.ToString()}");
            //Compare Records with the == Operator : True
            //Compare Records with the Equals Methode: True
            //Ausgabe mit ToString(): 
            //Car { Brand = BMW, Modell = Z8, radio = Radio { Brand = Telefunk, Modell = Model1 } }
        }
    }
}
