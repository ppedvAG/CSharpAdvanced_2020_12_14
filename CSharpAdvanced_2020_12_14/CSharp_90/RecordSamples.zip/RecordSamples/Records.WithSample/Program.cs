﻿using System;

namespace Records.WithSample
{
    class Program
    {
        public record Person(string Vorname, string Nachname);
        static void Main(string[] args)
        {
            Person p1 = new("Kevin", "Winter");

            Person p2 = p1 with
            {
                Nachname = "Mustermann"
            };
            Console.WriteLine($"{p2.ToString()}");
            //Person { Vorname = Kevin, Nachname = Mustermann }
            Console.ReadLine();
        }
    }
}
