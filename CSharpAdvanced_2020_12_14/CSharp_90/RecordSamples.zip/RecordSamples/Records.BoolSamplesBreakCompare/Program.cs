﻿using System;

namespace Records.BoolSamplesBreakCompare
{
    public record Blog(string Title, string Content, string[] Comments);
    class Program
    {
        static void Main(string[] args)
        {
            var blog1 = new Blog("C# 9", "{ State of .NET 5 } rockt!",
                new[]
                {
                    "Hat spaß gemacht!",
                    "Konnte vom HomeOffice teilnehmen :-)"
                });

            var blog2 = new Blog("C# 9", "{ State of .NET 5 } rockt!",
                new[]
                {
                    "Hat spaß gemacht!",
                    "Konnte vom HomeOffice teilnehmen :-)"
                });

            Console.WriteLine($"Compare Records with the == Operator : {blog1 == blog2}");
            Console.WriteLine($"Compare Records with the Equals Methode : {blog1.Equals(blog2)}");
            Console.WriteLine($"{blog1.ToString()}");
            Console.ReadKey();
            //Compare Records with the == Operator : False
            //Compare Records with the Equals Methode: False
            //Blog { Title = C# 9, Content = { State of .NET 5 } rockt!, Comments = System.String[] } }
        }
    }
}
