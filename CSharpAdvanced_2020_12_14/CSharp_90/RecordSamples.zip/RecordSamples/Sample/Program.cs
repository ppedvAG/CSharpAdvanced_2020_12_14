﻿using System;

namespace Sample
{
    public record Person(string Vorname, string Nachname);
    public class PersonClassSample
    {
        public string Vorname { get; init; }
        public string Nachname { get; init; }

        public PersonClassSample()
        {
            Vorname = Nachname = string.Empty;
        }
        public PersonClassSample(string vorname, string nachname)
        {
            this.Vorname = vorname;
            this.Nachname = nachname;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {


            Person person = new("Kevin", "Winter");


            PersonClassSample personClass = new();

            Console.WriteLine($"Record kann auch ToString(): {person.ToString()}");
            Console.WriteLine($"Vergleich zu einer Klassen-Instanz mit ToString(): {personClass.ToString()}");
            Console.ReadLine();
            //Ausgabe: Record kann auch ToString(): Person { Vorname = Kevin, Nachname = Winter }
            //Vergleich zu einer Klassen-Instanz mit ToString(): Sample.PersonClassSample
        }
    }
}

